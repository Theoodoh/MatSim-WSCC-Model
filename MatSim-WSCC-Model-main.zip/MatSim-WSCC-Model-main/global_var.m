
global m n Yred fYred
global IG0 delta0 Id0 Iq0 Vd0 Vq0 Epd0 Epq0 Efd0 TM VR0 Rf0 Vref Vref1 X0
global H Xd Xpd Xq Xpq Tpd0 Tpq0 ws M D KA TA KE TE KF TF Rs

global Kpss2 KG2 T21 T22 T23 T24 Tw
global Kpss3 KG3 T31 T32 T33 T34

global fault ftype event small_d
